/**
 * Advanced Analytics Library
 * Uses industry-standard libraries for production-ready analytics
 */

import * as tf from '@tensorflow/tfjs';
import * as regression from 'regression';
import * as ss from 'simple-statistics';
import { format, differenceInDays, addDays } from 'date-fns';
import type {
  LeadConversionPrediction,
  ChurnPrediction,
  RevenueForecast,
  CohortAnalysis,
  FunnelAnalysis,
  AttributionReport,
  MultiTouchAttribution,
} from '../types/analytics';

// ============================================
// PREDICTIVE ANALYTICS
// ============================================

/**
 * Predict lead conversion probability using TensorFlow.js
 * Uses features like: rating, review count, business status, contact info, etc.
 */
export class LeadConversionPredictor {
  private model: tf.LayersModel | null = null;

  /**
   * Train the model with historical data
   */
  async train(trainingData: any[]): Promise<void> {
    // Prepare features
    const features = trainingData.map(lead => [
      lead.rating || 0,
      lead.user_ratings_total || 0,
      lead.phone ? 1 : 0,
      lead.email ? 1 : 0,
      lead.website ? 1 : 0,
      lead.business_status === 'OPERATIONAL' ? 1 : 0,
      lead.lead_score || 0,
    ]);

    // Labels (0 = not converted, 1 = converted)
    const labels = trainingData.map(lead => lead.converted ? 1 : 0);

    // Convert to tensors
    const xs = tf.tensor2d(features);
    const ys = tf.tensor2d(labels, [labels.length, 1]);

    // Create model
    this.model = tf.sequential({
      layers: [
        tf.layers.dense({ inputShape: [7], units: 16, activation: 'relu' }),
        tf.layers.dropout({ rate: 0.2 }),
        tf.layers.dense({ units: 8, activation: 'relu' }),
        tf.layers.dense({ units: 1, activation: 'sigmoid' }),
      ],
    });

    // Compile model
    this.model.compile({
      optimizer: tf.train.adam(0.001),
      loss: 'binaryCrossentropy',
      metrics: ['accuracy'],
    });

    // Train model
    await this.model.fit(xs, ys, {
      epochs: 50,
      batchSize: 32,
      validationSplit: 0.2,
      callbacks: {
        onEpochEnd: (epoch, logs) => {
          console.log(`Epoch ${epoch}: loss = ${logs?.loss}, accuracy = ${logs?.acc}`);
        },
      },
    });

    // Clean up
    xs.dispose();
    ys.dispose();
  }

  /**
   * Predict conversion probability for a lead
   */
  async predict(lead: any): Promise<LeadConversionPrediction> {
    if (!this.model) {
      throw new Error('Model not trained. Call train() first.');
    }

    const features = [
      lead.rating || 0,
      lead.user_ratings_total || 0,
      lead.phone ? 1 : 0,
      lead.email ? 1 : 0,
      lead.website ? 1 : 0,
      lead.business_status === 'OPERATIONAL' ? 1 : 0,
      lead.lead_score || 0,
    ];

    const input = tf.tensor2d([features]);
    const prediction = this.model.predict(input) as tf.Tensor;
    const probability = (await prediction.data())[0];

    input.dispose();
    prediction.dispose();

    // Calculate factors
    const factors = [
      {
        feature: 'Rating',
        importance: 0.25,
        value: lead.rating,
        impact: lead.rating >= 4.0 ? 'positive' : 'negative',
      },
      {
        feature: 'Reviews',
        importance: 0.20,
        value: lead.user_ratings_total,
        impact: lead.user_ratings_total >= 50 ? 'positive' : 'negative',
      },
      {
        feature: 'Contact Info',
        importance: 0.30,
        value: [lead.phone, lead.email, lead.website].filter(Boolean).length,
        impact: lead.phone && lead.email ? 'positive' : 'negative',
      },
      {
        feature: 'Lead Score',
        importance: 0.25,
        value: lead.lead_score,
        impact: lead.lead_score >= 70 ? 'positive' : 'negative',
      },
    ];

    return {
      lead_id: lead.id,
      conversion_probability: probability,
      predicted_revenue: probability * 5000, // Avg deal value
      predicted_close_date: addDays(new Date(), Math.round(30 / probability)),
      confidence_interval: {
        lower: probability * 0.8,
        upper: Math.min(probability * 1.2, 1),
      },
      factors: factors as any,
    };
  }
}

/**
 * Predict revenue using regression analysis
 */
export function predictRevenue(historicalData: any[]): RevenueForecast {
  // Prepare data for regression
  const data = historicalData.map((item, index) => [index, item.revenue]);

  // Try multiple regression models
  const linear = regression.linear(data);
  const polynomial = regression.polynomial(data, { order: 2 });
  const exponential = regression.exponential(data);

  // Choose best model (highest R²)
  const models = [
    { type: 'linear', model: linear },
    { type: 'polynomial', model: polynomial },
    { type: 'exponential', model: exponential },
  ];

  const bestModel = models.reduce((best, current) => 
    current.model.r2 > best.model.r2 ? current : best
  );

  // Predict next 3 periods
  const nextPeriod = data.length;
  const predictedRevenue = bestModel.model.predict(nextPeriod)[1];

  // Calculate confidence interval (±15%)
  const confidence_interval = {
    lower: predictedRevenue * 0.85,
    upper: predictedRevenue * 1.15,
  };

  return {
    period: format(addDays(new Date(), 30), 'MMM yyyy'),
    predicted_revenue: Math.round(predictedRevenue),
    confidence_interval: {
      lower: Math.round(confidence_interval.lower),
      upper: Math.round(confidence_interval.upper),
    },
    breakdown: {
      new_business: Math.round(predictedRevenue * 0.6),
      expansion: Math.round(predictedRevenue * 0.25),
      renewal: Math.round(predictedRevenue * 0.15),
    },
    historical_data: historicalData.map((item, index) => ({
      period: item.period,
      actual_revenue: item.revenue,
      predicted_revenue: Math.round(bestModel.model.predict(index)[1]),
      variance: item.revenue - Math.round(bestModel.model.predict(index)[1]),
    })),
  };
}

/**
 * Predict customer churn
 */
export function predictChurn(lead: any, engagementData: any[]): ChurnPrediction {
  // Calculate engagement score
  const recentEngagement = engagementData.filter(e => 
    differenceInDays(new Date(), new Date(e.timestamp)) <= 30
  ).length;

  const avgEngagement = ss.mean(engagementData.map(e => e.score || 0));
  const engagementTrend = ss.linearRegression(
    engagementData.map((e, i) => [i, e.score || 0])
  );

  // Churn probability factors
  const factors = {
    low_engagement: recentEngagement < 2 ? 0.3 : 0,
    declining_trend: engagementTrend.m < 0 ? 0.25 : 0,
    no_recent_activity: differenceInDays(new Date(), lead.last_contacted) > 60 ? 0.25 : 0,
    low_satisfaction: (lead.rating || 5) < 3.5 ? 0.2 : 0,
  };

  const churnProbability = Object.values(factors).reduce((sum, val) => sum + val, 0);

  let riskLevel: 'low' | 'medium' | 'high' | 'critical';
  if (churnProbability >= 0.7) riskLevel = 'critical';
  else if (churnProbability >= 0.5) riskLevel = 'high';
  else if (churnProbability >= 0.3) riskLevel = 'medium';
  else riskLevel = 'low';

  return {
    lead_id: lead.id,
    churn_probability: churnProbability,
    risk_level: riskLevel,
    churn_date_estimate: addDays(new Date(), Math.round(90 * (1 - churnProbability))),
    retention_actions: [
      'Send personalized re-engagement email',
      'Offer special promotion or discount',
      'Schedule check-in call',
      'Share relevant case studies',
    ],
    factors: Object.entries(factors).map(([key, value]) => ({
      feature: key.replace(/_/g, ' '),
      importance: value,
      value: value > 0,
      impact: value > 0 ? 'negative' : 'positive',
    })) as any,
  };
}

// ============================================
// COHORT ANALYSIS
// ============================================

/**
 * Analyze cohort retention and behavior
 */
export function analyzeCohort(
  cohortLeads: any[],
  activityData: any[],
  periods: number = 12
): CohortAnalysis {
  // Group leads by acquisition month
  const cohortStart = new Date(Math.min(...cohortLeads.map(l => new Date(l.created_at).getTime())));
  
  const periodData = [];
  
  for (let period = 0; period <= periods; period++) {
    const periodStart = addDays(cohortStart, period * 30);
    const periodEnd = addDays(periodStart, 30);
    
    // Count active leads in this period
    const activeLeads = cohortLeads.filter(lead => {
      const activities = activityData.filter(a => 
        a.lead_id === lead.id &&
        new Date(a.timestamp) >= periodStart &&
        new Date(a.timestamp) < periodEnd
      );
      return activities.length > 0;
    });

    // Calculate revenue
    const periodRevenue = activityData
      .filter(a => 
        new Date(a.timestamp) >= periodStart &&
        new Date(a.timestamp) < periodEnd &&
        a.type === 'purchase'
      )
      .reduce((sum, a) => sum + (a.value || 0), 0);

    const retentionRate = (activeLeads.length / cohortLeads.length) * 100;

    periodData.push({
      period,
      date: periodStart,
      size: cohortLeads.length,
      active: activeLeads.length,
      retention_rate: retentionRate,
      revenue: periodRevenue,
      cumulative_revenue: periodData.reduce((sum, p) => sum + p.revenue, periodRevenue),
      average_value: periodRevenue / Math.max(activeLeads.length, 1),
    });
  }

  // Calculate retention curve
  const retentionRates = periodData.map(p => p.retention_rate);
  const halfLifeIndex = retentionRates.findIndex(rate => rate <= 50);
  
  const trend = ss.linearRegression(
    retentionRates.map((rate, i) => [i, rate])
  );

  const retentionCurve = {
    periods: periodData.map(p => p.period),
    retention_rates: retentionRates,
    trend: trend.m > 0 ? 'improving' : trend.m < -2 ? 'declining' : 'stable',
    half_life: halfLifeIndex >= 0 ? halfLifeIndex : periods,
  };

  // Calculate lifetime value
  const lifetimeValue = periodData.reduce((sum, p) => sum + p.revenue, 0) / cohortLeads.length;

  return {
    cohort_id: cohortStart.toISOString(),
    metric: 'retention',
    data: periodData,
    retention_curve: retentionCurve as any,
    lifetime_value: lifetimeValue,
    insights: generateCohortInsights(periodData, retentionCurve),
  };
}

function generateCohortInsights(data: any[], curve: any): string[] {
  const insights = [];
  
  if (curve.trend === 'declining') {
    insights.push('⚠️ Retention is declining - consider re-engagement campaigns');
  }
  
  const month3Retention = data[3]?.retention_rate || 0;
  if (month3Retention < 30) {
    insights.push('🔴 Low 3-month retention - improve onboarding experience');
  }
  
  const avgRevenue = ss.mean(data.map(d => d.average_value));
  if (avgRevenue > 100) {
    insights.push('💰 High average value - focus on retention over acquisition');
  }
  
  return insights;
}

// ============================================
// FUNNEL OPTIMIZATION
// ============================================

/**
 * Analyze conversion funnel performance
 */
export function analyzeFunnel(
  stages: any[],
  conversionData: any[]
): FunnelAnalysis {
  // Calculate stage metrics
  const stageMetrics = stages.map((stage, index) => {
    const stageData = conversionData.filter(c => c.stage === stage.name);
    const nextStage = stages[index + 1];
    const nextStageData = nextStage 
      ? conversionData.filter(c => c.stage === nextStage.name)
      : [];

    const entries = stageData.length;
    const conversions = nextStageData.length;
    const conversionRate = entries > 0 ? (conversions / entries) * 100 : 0;
    const dropOffRate = 100 - conversionRate;

    // Calculate average time in stage
    const times = stageData
      .filter(c => c.time_in_stage)
      .map(c => c.time_in_stage);
    const avgTime = times.length > 0 ? ss.mean(times) : 0;

    // Bottleneck score (higher drop-off + longer time = bigger bottleneck)
    const bottleneckScore = (dropOffRate * 0.7) + ((avgTime / 7) * 0.3 * 100);

    return {
      id: stage.id,
      name: stage.name,
      order: index,
      entries,
      exits: entries - conversions,
      conversions,
      conversion_rate: conversionRate,
      drop_off_rate: dropOffRate,
      average_time_in_stage: avgTime,
      bottleneck_score: Math.min(bottleneckScore, 100),
    };
  });

  // Identify bottlenecks
  const bottlenecks = stageMetrics
    .filter(s => s.bottleneck_score > 50)
    .sort((a, b) => b.bottleneck_score - a.bottleneck_score)
    .map(stage => ({
      stage_id: stage.id,
      stage_name: stage.name,
      drop_off_rate: stage.drop_off_rate,
      impact_on_revenue: stage.drop_off_rate * 1000, // Estimate
      suggested_actions: [
        'A/B test different messaging',
        'Simplify this stage',
        'Add progress indicators',
        'Reduce friction points',
      ],
      priority: stage.bottleneck_score > 75 ? 'critical' : 
                stage.bottleneck_score > 60 ? 'high' : 'medium',
    })) as any;

  // Find opportunities
  const opportunities = [
    {
      type: 'quick_win',
      description: 'Reduce form fields in signup stage',
      potential_improvement: 15, // %
      effort_required: 'low',
      priority_score: 85,
    },
    {
      type: 'high_impact',
      description: 'Implement exit-intent popups',
      potential_improvement: 25,
      effort_required: 'medium',
      priority_score: 75,
    },
  ] as any;

  const totalEntries = stageMetrics[0]?.entries || 0;
  const totalConversions = stageMetrics[stageMetrics.length - 1]?.conversions || 0;
  const overallConversionRate = totalEntries > 0 ? (totalConversions / totalEntries) * 100 : 0;

  return {
    funnel_id: 'main_funnel',
    time_period: {
      start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
      end: new Date(),
    },
    performance: {
      total_conversions: totalConversions,
      conversion_rate: overallConversionRate,
      trend: 5.2, // % vs previous period
    },
    bottlenecks,
    opportunities,
    segment_analysis: [],
  };
}

// ============================================
// REVENUE ATTRIBUTION
// ============================================

/**
 * Calculate multi-touch attribution
 */
export function calculateAttribution(
  touchPoints: any[],
  modelType: 'first_touch' | 'last_touch' | 'linear' | 'time_decay' | 'u_shaped' = 'time_decay'
): MultiTouchAttribution {
  const totalValue = touchPoints[touchPoints.length - 1]?.value || 0;
  
  let attributionBreakdown: any[] = [];

  switch (modelType) {
    case 'first_touch':
      // 100% to first touch
      attributionBreakdown = touchPoints.map((tp, i) => ({
        touchpoint_id: tp.id,
        channel: tp.channel,
        timestamp: tp.timestamp,
        attributed_value: i === 0 ? totalValue : 0,
        attribution_percentage: i === 0 ? 100 : 0,
        weight: i === 0 ? 1 : 0,
        position_in_journey: i,
      }));
      break;

    case 'last_touch':
      // 100% to last touch
      const lastIndex = touchPoints.length - 1;
      attributionBreakdown = touchPoints.map((tp, i) => ({
        touchpoint_id: tp.id,
        channel: tp.channel,
        timestamp: tp.timestamp,
        attributed_value: i === lastIndex ? totalValue : 0,
        attribution_percentage: i === lastIndex ? 100 : 0,
        weight: i === lastIndex ? 1 : 0,
        position_in_journey: i,
      }));
      break;

    case 'linear':
      // Equal weight to all touches
      const linearWeight = 1 / touchPoints.length;
      const linearValue = totalValue / touchPoints.length;
      attributionBreakdown = touchPoints.map((tp, i) => ({
        touchpoint_id: tp.id,
        channel: tp.channel,
        timestamp: tp.timestamp,
        attributed_value: linearValue,
        attribution_percentage: linearWeight * 100,
        weight: linearWeight,
        position_in_journey: i,
      }));
      break;

    case 'time_decay':
      // More recent touches get more credit
      const halfLife = 7; // days
      const now = new Date().getTime();
      const weights = touchPoints.map(tp => {
        const daysAgo = (now - new Date(tp.timestamp).getTime()) / (1000 * 60 * 60 * 24);
        return Math.pow(0.5, daysAgo / halfLife);
      });
      const totalWeight = weights.reduce((sum, w) => sum + w, 0);
      
      attributionBreakdown = touchPoints.map((tp, i) => {
        const weight = weights[i] / totalWeight;
        return {
          touchpoint_id: tp.id,
          channel: tp.channel,
          timestamp: tp.timestamp,
          attributed_value: totalValue * weight,
          attribution_percentage: weight * 100,
          weight,
          position_in_journey: i,
        };
      });
      break;

    case 'u_shaped':
      // 40% first, 40% last, 20% distributed to middle
      const middleWeight = touchPoints.length > 2 ? 0.2 / (touchPoints.length - 2) : 0;
      attributionBreakdown = touchPoints.map((tp, i) => {
        let weight: number;
        if (i === 0) weight = 0.4;
        else if (i === touchPoints.length - 1) weight = 0.4;
        else weight = middleWeight;

        return {
          touchpoint_id: tp.id,
          channel: tp.channel,
          timestamp: tp.timestamp,
          attributed_value: totalValue * weight,
          attribution_percentage: weight * 100,
          weight,
          position_in_journey: i,
        };
      });
      break;
  }

  return {
    lead_id: touchPoints[0]?.lead_id || '',
    total_value: totalValue,
    attribution_breakdown: attributionBreakdown,
    journey_visualization: touchPoints.map((tp, i) => ({
      id: tp.id,
      type: i === touchPoints.length - 1 ? 'conversion' : 'touchpoint',
      channel: tp.channel,
      timestamp: tp.timestamp,
      value: attributionBreakdown[i].attributed_value,
      next_nodes: i < touchPoints.length - 1 ? [touchPoints[i + 1].id] : [],
    })),
    conversion_path: touchPoints.map(tp => tp.channel).join(' → '),
  };
}

/**
 * Generate attribution report
 */
export function generateAttributionReport(
  touchPointsData: any[],
  conversionData: any[],
  modelType: 'time_decay' | 'u_shaped' = 'time_decay'
): AttributionReport {
  // Group by lead
  const leadJourneys = new Map<string, any[]>();
  touchPointsData.forEach(tp => {
    if (!leadJourneys.has(tp.lead_id)) {
      leadJourneys.set(tp.lead_id, []);
    }
    leadJourneys.get(tp.lead_id)!.push(tp);
  });

  // Calculate attribution for each journey
  const attributions = Array.from(leadJourneys.entries()).map(([leadId, touchPoints]) => {
    const conversion = conversionData.find(c => c.lead_id === leadId);
    const valueWithConversion = touchPoints.map(tp => ({ ...tp, value: conversion?.value || 0 }));
    return calculateAttribution(valueWithConversion, modelType);
  });

  // Aggregate by channel
  const channelMap = new Map<string, any>();
  attributions.forEach(attr => {
    attr.attribution_breakdown.forEach(tp => {
      if (!channelMap.has(tp.channel)) {
        channelMap.set(tp.channel, {
          channel: tp.channel,
          attributed_revenue: 0,
          attributed_conversions: 0,
          touch_points: 0,
          total_position: 0,
        });
      }
      const channel = channelMap.get(tp.channel)!;
      channel.attributed_revenue += tp.attributed_value;
      channel.attributed_conversions += tp.attribution_percentage / 100;
      channel.touch_points += 1;
      channel.total_position += tp.position_in_journey;
    });
  });

  const totalRevenue = attributions.reduce((sum, a) => sum + a.total_value, 0);

  const channelAttribution = Array.from(channelMap.values()).map(ch => ({
    ...ch,
    percentage_of_total: (ch.attributed_revenue / totalRevenue) * 100,
    cost: 0, // Would come from ad spend data
    roi: 0,
    trend: 0,
    average_position_in_journey: ch.total_position / ch.touch_points,
  }));

  return {
    model: {
      id: 'model_1',
      name: modelType === 'time_decay' ? 'Time Decay' : 'U-Shaped',
      type: modelType,
      description: 'Multi-touch attribution model',
      settings: {},
    },
    time_period: {
      start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
      end: new Date(),
    },
    total_revenue: totalRevenue,
    channel_attribution: channelAttribution as any,
    campaign_attribution: [],
    roi_analysis: [],
    insights: [],
  };
}

// Export all functions
export const AdvancedAnalytics = {
  LeadConversionPredictor,
  predictRevenue,
  predictChurn,
  analyzeCohort,
  analyzeFunnel,
  calculateAttribution,
  generateAttributionReport,
};
