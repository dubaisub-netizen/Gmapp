import ModernDashboard from './demo/page';

export default function Home() {
  return <ModernDashboard />;
}

// This is the main dashboard with all MVP features
export default function Dashboard() {
  const [activeView, setActiveView] = useState<'dashboard' | 'leads' | 'map' | 'reports' | 'analytics'>('dashboard');
  const [leads, setLeads] = useState<any[]>([]);
  const [stats, setStats] = useState({
    total_leads: 0,
    leads_today: 0,
    leads_this_week: 0,
    average_rating: 0,
    total_reviews: 0,
    ai_insights: 0
  });

  // Simulated data loading
  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = () => {
    // This would connect to InsForge backend
    setStats({
      total_leads: 12847,
      leads_today: 143,
      leads_this_week: 892,
      average_rating: 4.2,
      total_reviews: 45231,
      ai_insights: 1249
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Target className="w-8 h-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">LeadScout Pro</h1>
            </div>

            <div className="flex items-center space-x-4">
              {/* Search Bar */}
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search leads..."
                  className="w-96 px-4 py-2 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <Search className="w-5 h-5 text-gray-400 absolute left-3 top-2.5" />
              </div>

              {/* Notifications */}
              <button className="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg">
                <Bell className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>

              {/* New Scrape Button */}
              <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                <Plus className="w-5 h-5" />
                <span>New Scrape</span>
              </button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="mt-4 flex space-x-1">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
              { id: 'leads', label: 'Leads', icon: Database },
              { id: 'map', label: 'Map View', icon: MapIcon },
              { id: 'analytics', label: 'Analytics', icon: TrendingUp },
              { id: 'reports', label: 'Reports', icon: FileText },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveView(tab.id as any)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                  activeView === tab.id
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        {activeView === 'dashboard' && <DashboardView stats={stats} />}
        {activeView === 'leads' && <LeadsView leads={leads} />}
        {activeView === 'map' && <MapView />}
        {activeView === 'analytics' && <AnalyticsView />}
        {activeView === 'reports' && <ReportsView />}
      </main>
    </div>
  );
}

// Dashboard Overview Component
function DashboardView({ stats }: { stats: any }) {
  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <KPICard
          title="Total Leads"
          value={stats.total_leads.toLocaleString()}
          change="+12.5%"
          changeType="positive"
          icon={Database}
        />
        <KPICard
          title="Today's Leads"
          value={stats.leads_today.toLocaleString()}
          change="+8.2%"
          changeType="positive"
          icon={TrendingUp}
        />
        <KPICard
          title="Avg Rating"
          value={stats.average_rating.toFixed(1)}
          change="+0.3"
          changeType="positive"
          icon={BarChart3}
        />
        <KPICard
          title="AI Insights"
          value={stats.ai_insights.toLocaleString()}
          change="+24.1%"
          changeType="positive"
          icon={Zap}
        />
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <QuickActionButton
            icon={Search}
            title="Start New Scrape"
            description="Search and scrape new leads"
          />
          <QuickActionButton
            icon={Download}
            title="Export Data"
            description="Download leads to CSV/Excel"
          />
          <QuickActionButton
            icon={Zap}
            title="Run AI Analysis"
            description="Analyze leads with AI"
          />
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Leads by Category</h3>
          <div className="h-64 flex items-center justify-center text-gray-400">
            [Pie Chart: Categories Distribution]
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Rating Distribution</h3>
          <div className="h-64 flex items-center justify-center text-gray-400">
            [Bar Chart: Rating Distribution]
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="flex items-center justify-between py-3 border-b last:border-0">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <Database className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium">Scraped 250 restaurants in New York</p>
                  <p className="text-sm text-gray-500">2 hours ago</p>
                </div>
              </div>
              <span className="text-sm text-green-600 font-medium">Completed</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Leads List View Component
function LeadsView({ leads }: { leads: any[] }) {
  return (
    <div className="space-y-4">
      {/* Filters and Actions Bar */}
      <div className="bg-white rounded-lg shadow p-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <button className="flex items-center space-x-2 px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            <Filter className="w-4 h-4" />
            <span>Filters</span>
          </button>
          <select className="px-3 py-2 border border-gray-300 rounded-lg">
            <option>All Status</option>
            <option>New</option>
            <option>Contacted</option>
            <option>Qualified</option>
          </select>
          <select className="px-3 py-2 border border-gray-300 rounded-lg">
            <option>All Categories</option>
            <option>Restaurants</option>
            <option>Retail</option>
            <option>Services</option>
          </select>
        </div>

        <div className="flex items-center space-x-2">
          <button className="px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            <Download className="w-4 h-4" />
          </button>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            Export Selected
          </button>
        </div>
      </div>

      {/* Leads Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                <input type="checkbox" className="rounded" />
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Business
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Category
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Rating
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Contact
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Score
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {[1, 2, 3, 4, 5].map((i) => (
              <tr key={i} className="hover:bg-gray-50">
                <td className="px-6 py-4">
                  <input type="checkbox" className="rounded" />
                </td>
                <td className="px-6 py-4">
                  <div>
                    <div className="font-medium text-gray-900">Sample Restaurant {i}</div>
                    <div className="text-sm text-gray-500">123 Main St, New York, NY</div>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-gray-900">Restaurant</td>
                <td className="px-6 py-4">
                  <div className="flex items-center">
                    <span className="text-yellow-500">★</span>
                    <span className="ml-1 text-sm font-medium">4.{i}</span>
                    <span className="ml-1 text-xs text-gray-500">(234)</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm">
                  <div>(555) 123-456{i}</div>
                  <div className="text-gray-500">sample{i}@email.com</div>
                </td>
                <td className="px-6 py-4">
                  <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                    {75 + i}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                    New
                  </span>
                </td>
                <td className="px-6 py-4">
                  <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                    View
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="bg-white rounded-lg shadow p-4 flex items-center justify-between">
        <div className="text-sm text-gray-700">
          Showing <span className="font-medium">1</span> to <span className="font-medium">10</span> of{' '}
          <span className="font-medium">1,247</span> results
        </div>
        <div className="flex space-x-2">
          <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50">Previous</button>
          <button className="px-3 py-1 bg-blue-600 text-white rounded">1</button>
          <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50">2</button>
          <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50">3</button>
          <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50">Next</button>
        </div>
      </div>
    </div>
  );
}

// Map View Component
function MapView() {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">Map View</h2>
        <div className="flex space-x-2">
          <button className="px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            Cluster View
          </button>
          <button className="px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            Heat Map
          </button>
        </div>
      </div>
      <div className="h-[600px] bg-gray-100 rounded-lg flex items-center justify-center text-gray-400">
        [Interactive Map with Lead Markers]
        <p className="text-sm">Map integration: Google Maps / Mapbox</p>
      </div>
    </div>
  );
}

// Analytics View Component
function AnalyticsView() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Leads Over Time</h3>
          <div className="h-64 flex items-center justify-center text-gray-400">
            [Line Chart: Leads Growth]
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Conversion Funnel</h3>
          <div className="h-64 flex items-center justify-center text-gray-400">
            [Funnel Chart]
          </div>
        </div>
      </div>
    </div>
  );
}

// Reports View Component
function ReportsView() {
  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold mb-4">Generate Report</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            'Market Analysis',
            'Competitive Landscape',
            'Lead Performance',
            'Campaign Performance',
            'Executive Summary',
            'Territory Analysis',
          ].map((report) => (
            <button
              key={report}
              className="p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all"
            >
              <FileText className="w-8 h-8 text-blue-600 mb-2" />
              <h3 className="font-medium">{report}</h3>
              <p className="text-sm text-gray-500 mt-1">Generate detailed report</p>
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold mb-4">Recent Reports</h3>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
              <div className="flex items-center space-x-3">
                <FileText className="w-8 h-8 text-blue-600" />
                <div>
                  <p className="font-medium">Market Analysis Report - Q1 2024</p>
                  <p className="text-sm text-gray-500">Generated on Feb {i}, 2024</p>
                </div>
              </div>
              <div className="flex space-x-2">
                <button className="px-3 py-1 text-blue-600 hover:bg-blue-50 rounded">View</button>
                <button className="px-3 py-1 text-gray-600 hover:bg-gray-50 rounded">Download</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Utility Components
function KPICard({ title, value, change, changeType, icon: Icon }: any) {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-600 mb-1">{title}</p>
          <p className="text-2xl font-bold text-gray-900">{value}</p>
          <p className={`text-sm mt-1 ${changeType === 'positive' ? 'text-green-600' : 'text-red-600'}`}>
            {change} from last period
          </p>
        </div>
        <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
          <Icon className="w-6 h-6 text-blue-600" />
        </div>
      </div>
    </div>
  );
}

function QuickActionButton({ icon: Icon, title, description }: any) {
  return (
    <button className="flex items-start space-x-3 p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all text-left">
      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
        <Icon className="w-5 h-5 text-blue-600" />
      </div>
      <div>
        <h4 className="font-medium text-gray-900">{title}</h4>
        <p className="text-sm text-gray-500 mt-1">{description}</p>
      </div>
    </button>
  );
}
