'use client';

import { useState } from 'react';
import {
  LayoutDashboard,
  Users,
  Target,
  Map,
  BarChart3,
  FileText,
  Settings,
  Search,
  Bell,
  ChevronRight,
  TrendingUp,
  DollarSign,
  Activity,
  Zap,
  Brain,
  Phone,
  MessageSquare,
  Mail,
  Calendar,
  Download,
  Filter,
  Plus,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';

export default function ModernDashboard() {
  const [activeView, setActiveView] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Modern Sidebar */}
      <aside
        className={`fixed left-0 top-0 h-full bg-white/80 backdrop-blur-xl border-r border-gray-200/50 shadow-2xl z-50 transition-all duration-300 ${
          sidebarOpen ? 'w-64' : 'w-20'
        }`}
      >
        {/* Logo */}
        <div className="h-20 flex items-center justify-center border-b border-gray-100">
          {sidebarOpen ? (
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                LeadScout
              </span>
            </div>
          ) : (
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
          )}
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-2">
          {[
            { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard', badge: null },
            { id: 'leads', icon: Users, label: 'Leads', badge: '1.2k' },
            { id: 'scrape', icon: Target, label: 'Scrape', badge: null },
            { id: 'map', icon: Map, label: 'Map View', badge: null },
            { id: 'analytics', icon: BarChart3, label: 'Analytics', badge: 'New' },
            { id: 'ai-agents', icon: Brain, label: 'AI Agents', badge: 'New' },
            { id: 'reports', icon: FileText, label: 'Reports', badge: null },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
                activeView === item.id
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-500/50'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              {sidebarOpen && (
                <>
                  <span className="font-medium flex-1 text-left">{item.label}</span>
                  {item.badge && (
                    <span
                      className={`px-2 py-0.5 text-xs font-semibold rounded-full ${
                        activeView === item.id
                          ? 'bg-white/20 text-white'
                          : item.badge === 'New'
                          ? 'bg-green-100 text-green-700'
                          : 'bg-blue-100 text-blue-700'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </>
              )}
            </button>
          ))}
        </nav>

        {/* User Profile */}
        {sidebarOpen && (
          <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-100">
            <div className="flex items-center space-x-3 p-3 rounded-xl hover:bg-gray-50 cursor-pointer transition-all">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white font-semibold">
                JD
              </div>
              <div className="flex-1">
                <p className="font-medium text-gray-900">John Doe</p>
                <p className="text-xs text-gray-500">john@company.com</p>
              </div>
              <Settings className="w-5 h-5 text-gray-400" />
            </div>
          </div>
        )}
      </aside>

      {/* Main Content */}
      <main className={`transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-20'}`}>
        {/* Top Bar */}
        <header className="h-20 bg-white/80 backdrop-blur-xl border-b border-gray-200/50 sticky top-0 z-40">
          <div className="h-full px-8 flex items-center justify-between">
            {/* Search */}
            <div className="flex-1 max-w-2xl">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search leads, companies, or insights..."
                  className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                />
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center space-x-4 ml-8">
              <button className="relative p-2 text-gray-600 hover:bg-gray-100 rounded-xl transition-all">
                <Bell className="w-6 h-6" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>
              <button className="px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl font-medium hover:shadow-lg hover:shadow-blue-500/50 transition-all flex items-center space-x-2">
                <Plus className="w-5 h-5" />
                <span>New Scrape</span>
              </button>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="p-8">
          {activeView === 'dashboard' && <DashboardView />}
          {activeView === 'leads' && <LeadsView />}
          {activeView === 'analytics' && <AnalyticsView />}
          {activeView === 'ai-agents' && <AIAgentsView />}
        </div>
      </main>
    </div>
  );
}

// ============================================
// DASHBOARD VIEW (Trendy & Modern)
// ============================================

function DashboardView() {
  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 rounded-2xl p-8 text-white shadow-2xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Welcome back, John! 👋</h1>
            <p className="text-blue-100 text-lg">
              You have 847 hot leads waiting for your attention
            </p>
          </div>
          <div className="hidden lg:block">
            <div className="w-32 h-32 bg-white/10 backdrop-blur-lg rounded-2xl flex items-center justify-center">
              <TrendingUp className="w-16 h-16" />
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards - Modern Glass Morphism */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Total Leads"
          value="12,847"
          change="+12.5%"
          trend="up"
          icon={Users}
          color="blue"
        />
        <MetricCard
          title="Conversion Rate"
          value="24.8%"
          change="+3.2%"
          trend="up"
          icon={Target}
          color="green"
        />
        <MetricCard
          title="Revenue"
          value="$124.5K"
          change="+18.4%"
          trend="up"
          icon={DollarSign}
          color="purple"
        />
        <MetricCard
          title="AI Predictions"
          value="1,249"
          change="+45.2%"
          trend="up"
          icon={Brain}
          color="indigo"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Hot Leads - 2/3 width */}
        <div className="lg:col-span-2 bg-white/80 backdrop-blur-xl rounded-2xl p-6 border border-gray-200/50 shadow-xl">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">🔥 Hot Leads</h2>
            <button className="text-sm text-blue-600 font-medium hover:text-blue-700 flex items-center space-x-1">
              <span>View All</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="space-y-3">
            {[
              {
                name: 'Acme Corporation',
                score: 94,
                revenue: '$15,000',
                status: 'Hot',
                trend: 'up',
              },
              {
                name: 'Tech Solutions Inc',
                score: 89,
                revenue: '$12,500',
                status: 'Hot',
                trend: 'up',
              },
              {
                name: 'Global Ventures',
                score: 85,
                revenue: '$22,000',
                status: 'Warm',
                trend: 'up',
              },
            ].map((lead, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-blue-50/50 rounded-xl hover:shadow-md transition-all cursor-pointer group"
              >
                <div className="flex items-center space-x-4 flex-1">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-500 flex items-center justify-center text-white font-bold text-lg shadow-lg">
                    {lead.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                      {lead.name}
                    </p>
                    <p className="text-sm text-gray-500">{lead.revenue} potential value</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <div className="flex items-center space-x-2">
                      <div className="w-16 bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-gradient-to-r from-green-400 to-green-600 h-2 rounded-full"
                          style={{ width: `${lead.score}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-bold text-green-600">{lead.score}</span>
                    </div>
                  </div>
                  <button className="px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-all text-sm">
                    Contact
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions - 1/3 width */}
        <div className="space-y-6">
          <div className="bg-white/80 backdrop-blur-xl rounded-2xl p-6 border border-gray-200/50 shadow-xl">
            <h3 className="text-lg font-bold text-gray-900 mb-4">⚡ Quick Actions</h3>
            <div className="space-y-3">
              {[
                { icon: Target, label: 'New Scrape', color: 'blue' },
                { icon: Phone, label: 'Start Calls', color: 'green' },
                { icon: Mail, label: 'Email Campaign', color: 'purple' },
                { icon: Download, label: 'Export Data', color: 'indigo' },
              ].map((action, i) => (
                <button
                  key={i}
                  className="w-full flex items-center space-x-3 p-3 rounded-xl hover:bg-gray-50 transition-all group"
                >
                  <div
                    className={`w-10 h-10 rounded-lg bg-${action.color}-100 flex items-center justify-center group-hover:scale-110 transition-transform`}
                  >
                    <action.icon className={`w-5 h-5 text-${action.color}-600`} />
                  </div>
                  <span className="font-medium text-gray-700 group-hover:text-gray-900">
                    {action.label}
                  </span>
                  <ChevronRight className="w-4 h-4 text-gray-400 ml-auto" />
                </button>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl p-6 text-white shadow-xl">
            <h3 className="text-lg font-bold mb-2">🎯 Today's Goal</h3>
            <p className="text-green-100 mb-4">Contact 50 hot leads</p>
            <div className="mb-2">
              <div className="flex justify-between text-sm mb-1">
                <span>Progress</span>
                <span className="font-bold">32/50</span>
              </div>
              <div className="w-full bg-white/20 rounded-full h-2">
                <div className="bg-white h-2 rounded-full" style={{ width: '64%' }}></div>
              </div>
            </div>
            <p className="text-xs text-green-100">Great work! Keep going 💪</p>
          </div>
        </div>
      </div>

      {/* Activity Chart */}
      <div className="bg-white/80 backdrop-blur-xl rounded-2xl p-6 border border-gray-200/50 shadow-xl">
        <h2 className="text-xl font-bold text-gray-900 mb-6">📈 Performance Trends</h2>
        <div className="h-80 flex items-center justify-center text-gray-400 border-2 border-dashed border-gray-200 rounded-xl">
          [Beautiful Interactive Chart - Leads & Revenue Over Time]
        </div>
      </div>
    </div>
  );
}

// ============================================
// LEADS VIEW
// ============================================

function LeadsView() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">All Leads</h1>
        <div className="flex items-center space-x-3">
          <button className="px-4 py-2 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 flex items-center space-x-2">
            <Filter className="w-4 h-4" />
            <span>Filters</span>
          </button>
          <button className="px-4 py-2 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 flex items-center space-x-2">
            <Download className="w-4 h-4" />
            <span>Export</span>
          </button>
        </div>
      </div>

      <div className="bg-white/80 backdrop-blur-xl rounded-2xl border border-gray-200/50 shadow-xl overflow-hidden">
        <div className="p-6">
          <p className="text-gray-600">Showing 1,247 leads</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-y border-gray-200">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">
                  Business
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">
                  Score
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">
                  Rating
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">
                  Contact
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">
                  Status
                </th>
                <th className="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {/* Table rows would go here */}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ============================================
// ANALYTICS VIEW
// ============================================

function AnalyticsView() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Advanced Analytics</h1>
      <div className="text-gray-600">See ADVANCED_ANALYTICS.md for implementation</div>
    </div>
  );
}

// ============================================
// AI AGENTS VIEW (Phase 11)
// ============================================

function AIAgentsView() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">🤖 AI Agents</h1>
          <p className="text-gray-600">Automate your sales process with intelligent agents</p>
        </div>
        <button className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl font-medium hover:shadow-lg transition-all flex items-center space-x-2">
          <Plus className="w-5 h-5" />
          <span>Create Agent</span>
        </button>
      </div>

      {/* Agent Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[
          {
            name: 'Voice AI Caller',
            icon: Phone,
            status: 'Active',
            calls: 142,
            success: '67%',
            color: 'blue',
          },
          {
            name: 'Chat Qualifier',
            icon: MessageSquare,
            status: 'Active',
            calls: 89,
            success: '82%',
            color: 'green',
          },
          {
            name: 'Email Assistant',
            icon: Mail,
            status: 'Paused',
            calls: 56,
            success: '74%',
            color: 'purple',
          },
        ].map((agent, i) => (
          <div
            key={i}
            className="bg-white/80 backdrop-blur-xl rounded-2xl p-6 border border-gray-200/50 shadow-xl hover:shadow-2xl transition-all"
          >
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 rounded-xl bg-${agent.color}-100 flex items-center justify-center`}>
                <agent.icon className={`w-6 h-6 text-${agent.color}-600`} />
              </div>
              <span
                className={`px-3 py-1 text-xs font-semibold rounded-full ${
                  agent.status === 'Active'
                    ? 'bg-green-100 text-green-700'
                    : 'bg-gray-100 text-gray-700'
                }`}
              >
                {agent.status}
              </span>
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-2">{agent.name}</h3>
            <div className="space-y-2 mb-4">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Total Interactions</span>
                <span className="font-semibold text-gray-900">{agent.calls}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Success Rate</span>
                <span className="font-semibold text-green-600">{agent.success}</span>
              </div>
            </div>
            <button className="w-full px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg font-medium transition-all">
              View Details
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================
// UTILITY COMPONENTS
// ============================================

function MetricCard({ title, value, change, trend, icon: Icon, color }: any) {
  const colors = {
    blue: 'from-blue-500 to-indigo-500',
    green: 'from-green-500 to-emerald-500',
    purple: 'from-purple-500 to-pink-500',
    indigo: 'from-indigo-500 to-purple-500',
  };

  return (
    <div className="bg-white/80 backdrop-blur-xl rounded-2xl p-6 border border-gray-200/50 shadow-xl hover:shadow-2xl transition-all group">
      <div className="flex items-center justify-between mb-4">
        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${colors[color]} flex items-center justify-center shadow-lg`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        <div className={`flex items-center space-x-1 text-sm font-semibold ${
          trend === 'up' ? 'text-green-600' : 'text-red-600'
        }`}>
          {trend === 'up' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
          <span>{change}</span>
        </div>
      </div>
      <p className="text-sm text-gray-600 mb-1">{title}</p>
      <p className="text-3xl font-bold text-gray-900">{value}</p>
    </div>
  );
}
