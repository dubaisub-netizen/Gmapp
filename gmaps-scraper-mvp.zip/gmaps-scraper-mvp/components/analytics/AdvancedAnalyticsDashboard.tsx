'use client';

import { useState, useEffect } from 'react';
import {
  TrendingUp,
  Users,
  Target,
  DollarSign,
  Brain,
  Activity,
  BarChart3,
  Zap,
  AlertCircle,
  ArrowUp,
  ArrowDown,
  Info,
} from 'lucide-react';

// ============================================
// MAIN ADVANCED ANALYTICS DASHBOARD
// ============================================

export default function AdvancedAnalyticsDashboard() {
  const [activeTab, setActiveTab] = useState<'predictive' | 'cohort' | 'funnel' | 'attribution'>('predictive');
  const [timeRange, setTimeRange] = useState('30d');

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Advanced Analytics</h1>
        <p className="text-gray-600">AI-powered insights and predictive intelligence</p>
      </div>

      {/* Time Range Selector */}
      <div className="bg-white rounded-lg shadow p-4 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex space-x-2">
            {['7d', '30d', '90d', '1y', 'all'].map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  timeRange === range
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {range === '7d' && 'Last 7 Days'}
                {range === '30d' && 'Last 30 Days'}
                {range === '90d' && 'Last Quarter'}
                {range === '1y' && 'Last Year'}
                {range === 'all' && 'All Time'}
              </button>
            ))}
          </div>
          <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
            Export Report
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white rounded-lg shadow mb-6">
        <div className="flex border-b">
          {[
            { id: 'predictive', label: 'Predictive Analytics', icon: Brain },
            { id: 'cohort', label: 'Cohort Analysis', icon: Users },
            { id: 'funnel', label: 'Funnel Optimization', icon: Target },
            { id: 'attribution', label: 'Revenue Attribution', icon: DollarSign },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-6 py-4 border-b-2 transition-colors ${
                activeTab === tab.id
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              <span className="font-medium">{tab.label}</span>
            </button>
          ))}
        </div>

        <div className="p-6">
          {activeTab === 'predictive' && <PredictiveAnalyticsView />}
          {activeTab === 'cohort' && <CohortAnalysisView />}
          {activeTab === 'funnel' && <FunnelOptimizationView />}
          {activeTab === 'attribution' && <RevenueAttributionView />}
        </div>
      </div>
    </div>
  );
}

// ============================================
// 1. PREDICTIVE ANALYTICS VIEW
// ============================================

function PredictiveAnalyticsView() {
  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <PredictiveMetricCard
          title="Predicted Revenue"
          value="$124,500"
          change="+12.5%"
          trend="up"
          icon={DollarSign}
          description="Next 30 days forecast"
        />
        <PredictiveMetricCard
          title="High Probability Leads"
          value="847"
          change="+8.3%"
          trend="up"
          icon={Target}
          description="Conversion > 70%"
        />
        <PredictiveMetricCard
          title="Churn Risk"
          value="23"
          change="-5.2%"
          trend="down"
          icon={AlertCircle}
          description="Critical risk level"
        />
        <PredictiveMetricCard
          title="Model Accuracy"
          value="87.3%"
          change="+2.1%"
          trend="up"
          icon={Brain}
          description="Prediction confidence"
        />
      </div>

      {/* Revenue Forecast Chart */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Revenue Forecast</h3>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600">Model:</span>
            <select className="px-3 py-1 border border-gray-300 rounded-lg text-sm">
              <option>Time Series</option>
              <option>Linear Regression</option>
              <option>Neural Network</option>
            </select>
          </div>
        </div>
        <div className="h-80 flex items-center justify-center text-gray-400 border-2 border-dashed rounded-lg">
          [Revenue Forecast Line Chart]
          <br />
          Historical data (blue) + Predicted values (dashed) + Confidence interval (shaded)
        </div>
        <div className="mt-4 grid grid-cols-3 gap-4">
          <div className="text-center">
            <p className="text-sm text-gray-600">Conservative</p>
            <p className="text-xl font-bold text-gray-900">$98,200</p>
          </div>
          <div className="text-center">
            <p className="text-sm text-gray-600">Expected</p>
            <p className="text-2xl font-bold text-blue-600">$124,500</p>
          </div>
          <div className="text-center">
            <p className="text-sm text-gray-600">Optimistic</p>
            <p className="text-xl font-bold text-gray-900">$156,800</p>
          </div>
        </div>
      </div>

      {/* High Probability Leads */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Conversion Predictions</h3>
          <div className="space-y-3">
            {[
              { name: 'Acme Corp', probability: 0.92, value: 15000, days: 12 },
              { name: 'Tech Solutions Inc', probability: 0.87, value: 12500, days: 18 },
              { name: 'Global Ventures', probability: 0.84, value: 22000, days: 25 },
              { name: 'Innovation Labs', probability: 0.81, value: 8500, days: 15 },
              { name: 'Digital Dynamics', probability: 0.78, value: 11200, days: 20 },
            ].map((lead, i) => (
              <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{lead.name}</p>
                  <p className="text-sm text-gray-600">${lead.value.toLocaleString()} • {lead.days} days to close</p>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="text-right">
                    <p className="text-lg font-bold text-green-600">{(lead.probability * 100).toFixed(0)}%</p>
                    <p className="text-xs text-gray-500">Probability</p>
                  </div>
                  <button className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">
                    View
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Churn Risk Alerts */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Churn Risk Alerts</h3>
          <div className="space-y-3">
            {[
              { name: 'Beta Industries', risk: 0.85, value: 9500, days: 15, level: 'critical' },
              { name: 'Omega Systems', risk: 0.72, value: 14200, days: 30, level: 'high' },
              { name: 'Sigma Corp', risk: 0.64, value: 7800, days: 45, level: 'high' },
              { name: 'Delta Partners', risk: 0.51, value: 11000, days: 60, level: 'medium' },
            ].map((lead, i) => (
              <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${
                    lead.level === 'critical' ? 'bg-red-600' :
                    lead.level === 'high' ? 'bg-orange-500' : 'bg-yellow-500'
                  }`} />
                  <div>
                    <p className="font-medium text-gray-900">{lead.name}</p>
                    <p className="text-sm text-gray-600">LTV: ${lead.value.toLocaleString()} • {lead.days}d to churn</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="text-right">
                    <p className="text-lg font-bold text-red-600">{(lead.risk * 100).toFixed(0)}%</p>
                    <p className="text-xs text-gray-500">Risk</p>
                  </div>
                  <button className="px-3 py-1 bg-orange-600 text-white text-sm rounded hover:bg-orange-700">
                    Action
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* AI Insights */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200 p-6">
        <div className="flex items-start space-x-3">
          <Brain className="w-6 h-6 text-blue-600 mt-1" />
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">AI-Powered Insights</h3>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start space-x-2">
                <Zap className="w-4 h-4 text-yellow-500 mt-1 flex-shrink-0" />
                <span>
                  <strong>Quick Win:</strong> Focus on leads with ratings above 4.5 - they convert 3x faster
                </span>
              </li>
              <li className="flex items-start space-x-2">
                <TrendingUp className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
                <span>
                  <strong>Trend Alert:</strong> Restaurant category showing 28% increase in conversion this month
                </span>
              </li>
              <li className="flex items-start space-x-2">
                <AlertCircle className="w-4 h-4 text-red-500 mt-1 flex-shrink-0" />
                <span>
                  <strong>Warning:</strong> 23 high-value leads at critical churn risk - immediate action recommended
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================
// 2. COHORT ANALYSIS VIEW
// ============================================

function CohortAnalysisView() {
  return (
    <div className="space-y-6">
      {/* Cohort Selector */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Cohort Analysis</h2>
          <p className="text-gray-600">Track lead retention and value over time</p>
        </div>
        <select className="px-4 py-2 border border-gray-300 rounded-lg">
          <option>Monthly Cohorts</option>
          <option>Weekly Cohorts</option>
          <option>Quarterly Cohorts</option>
          <option>Custom Date Range</option>
        </select>
      </div>

      {/* Retention Heatmap */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Retention Heatmap</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-left py-2 px-3 text-gray-600 font-medium">Cohort</th>
                <th className="text-center py-2 px-3 text-gray-600 font-medium">Size</th>
                {[0, 1, 2, 3, 4, 5, 6].map((month) => (
                  <th key={month} className="text-center py-2 px-3 text-gray-600 font-medium">
                    M{month}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                { cohort: 'Jan 2024', size: 1234, retention: [100, 85, 72, 65, 58, 52, 48] },
                { cohort: 'Feb 2024', size: 1456, retention: [100, 88, 76, 68, 62, 56, null] },
                { cohort: 'Mar 2024', size: 1589, retention: [100, 90, 78, 71, 65, null, null] },
                { cohort: 'Apr 2024', size: 1702, retention: [100, 87, 74, 67, null, null, null] },
                { cohort: 'May 2024', size: 1823, retention: [100, 89, 77, null, null, null, null] },
              ].map((row, i) => (
                <tr key={i} className="border-b hover:bg-gray-50">
                  <td className="py-2 px-3 font-medium text-gray-900">{row.cohort}</td>
                  <td className="text-center py-2 px-3 text-gray-700">{row.size.toLocaleString()}</td>
                  {row.retention.map((rate, j) => (
                    <td key={j} className="text-center py-2 px-3">
                      {rate !== null ? (
                        <span
                          className="inline-block px-2 py-1 rounded text-xs font-medium"
                          style={{
                            backgroundColor: `rgba(34, 197, 94, ${rate / 100})`,
                            color: rate > 60 ? 'white' : '#166534',
                          }}
                        >
                          {rate}%
                        </span>
                      ) : (
                        <span className="text-gray-300">—</span>
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Cohort Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h4 className="text-sm font-medium text-gray-600 mb-2">30-Day Retention</h4>
          <p className="text-3xl font-bold text-gray-900">87.5%</p>
          <p className="text-sm text-green-600 mt-1">+3.2% vs last period</p>
          <div className="mt-4 h-32 flex items-center justify-center text-gray-400 border-2 border-dashed rounded">
            [Retention Trend Chart]
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h4 className="text-sm font-medium text-gray-600 mb-2">Lifetime Value</h4>
          <p className="text-3xl font-bold text-gray-900">$2,847</p>
          <p className="text-sm text-green-600 mt-1">+12.8% vs last period</p>
          <div className="mt-4 h-32 flex items-center justify-center text-gray-400 border-2 border-dashed rounded">
            [LTV Trend Chart]
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h4 className="text-sm font-medium text-gray-600 mb-2">Payback Period</h4>
          <p className="text-3xl font-bold text-gray-900">4.2 months</p>
          <p className="text-sm text-green-600 mt-1">-0.8 months improvement</p>
          <div className="mt-4 h-32 flex items-center justify-center text-gray-400 border-2 border-dashed rounded">
            [Payback Trend Chart]
          </div>
        </div>
      </div>

      {/* Cohort Comparison */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Cohort Performance Comparison</h3>
        <div className="h-64 flex items-center justify-center text-gray-400 border-2 border-dashed rounded-lg">
          [Multi-line Chart comparing different cohorts over time]
        </div>
      </div>
    </div>
  );
}

// ============================================
// 3. FUNNEL OPTIMIZATION VIEW
// ============================================

function FunnelOptimizationView() {
  const funnelStages = [
    { name: 'Awareness', entries: 10000, conversions: 7500, rate: 75, avgDays: 0.5 },
    { name: 'Interest', entries: 7500, conversions: 5250, rate: 70, avgDays: 2.1 },
    { name: 'Consideration', entries: 5250, conversions: 3675, rate: 70, avgDays: 5.3 },
    { name: 'Intent', entries: 3675, conversions: 2572, rate: 70, avgDays: 8.7 },
    { name: 'Evaluation', entries: 2572, conversions: 1800, rate: 70, avgDays: 12.4 },
    { name: 'Purchase', entries: 1800, conversions: 1260, rate: 70, avgDays: 3.2 },
  ];

  return (
    <div className="space-y-6">
      {/* Funnel Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <p className="text-sm text-gray-600 mb-1">Total Entries</p>
          <p className="text-3xl font-bold text-gray-900">10,000</p>
          <p className="text-sm text-green-600 mt-1">+15.3% vs last month</p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <p className="text-sm text-gray-600 mb-1">Total Conversions</p>
          <p className="text-3xl font-bold text-gray-900">1,260</p>
          <p className="text-sm text-green-600 mt-1">+8.7% vs last month</p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <p className="text-sm text-gray-600 mb-1">Conversion Rate</p>
          <p className="text-3xl font-bold text-gray-900">12.6%</p>
          <p className="text-sm text-red-600 mt-1">-2.1% vs last month</p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <p className="text-sm text-gray-600 mb-1">Avg Time to Convert</p>
          <p className="text-3xl font-bold text-gray-900">32.3d</p>
          <p className="text-sm text-green-600 mt-1">-4.2d improvement</p>
        </div>
      </div>

      {/* Funnel Visualization */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Conversion Funnel</h3>
        <div className="space-y-4">
          {funnelStages.map((stage, index) => {
            const widthPercent = (stage.entries / funnelStages[0].entries) * 100;
            const dropOff = index > 0 ? funnelStages[index - 1].entries - stage.entries : 0;
            const dropOffRate = index > 0 ? ((dropOff / funnelStages[index - 1].entries) * 100).toFixed(1) : '0';

            return (
              <div key={stage.name} className="relative">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-3">
                    <span className="text-lg font-semibold text-gray-900">{stage.name}</span>
                    {dropOff > 0 && (
                      <span className="text-sm text-red-600">
                        -{dropOffRate}% drop-off
                      </span>
                    )}
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600">
                      {stage.entries.toLocaleString()} → {stage.conversions.toLocaleString()}
                    </p>
                    <p className="text-xs text-gray-500">{stage.rate}% convert • {stage.avgDays}d avg</p>
                  </div>
                </div>
                <div className="relative h-16 bg-gray-100 rounded-lg overflow-hidden">
                  <div
                    className="absolute inset-y-0 left-0 bg-gradient-to-r from-blue-500 to-blue-600 flex items-center justify-center transition-all duration-500"
                    style={{ width: `${widthPercent}%` }}
                  >
                    <span className="text-white font-semibold">
                      {stage.entries.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottlenecks & Opportunities */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-red-50 rounded-lg border border-red-200 p-6">
          <h3 className="text-lg font-semibold text-red-900 mb-4 flex items-center">
            <AlertCircle className="w-5 h-5 mr-2" />
            Biggest Bottlenecks
          </h3>
          <div className="space-y-3">
            {[
              { stage: 'Interest → Consideration', impact: 'High', dropOff: 30, suggestion: 'Add product demos' },
              { stage: 'Intent → Evaluation', impact: 'Medium', dropOff: 25, suggestion: 'Simplify pricing page' },
              { stage: 'Evaluation → Purchase', impact: 'Medium', dropOff: 30, suggestion: 'Add trust signals' },
            ].map((bottleneck, i) => (
              <div key={i} className="bg-white rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-medium text-gray-900">{bottleneck.stage}</p>
                    <p className="text-sm text-gray-600">{bottleneck.dropOff}% drop-off rate</p>
                  </div>
                  <span className={`px-2 py-1 text-xs font-medium rounded ${
                    bottleneck.impact === 'High' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {bottleneck.impact} Impact
                  </span>
                </div>
                <p className="text-sm text-gray-700">💡 {bottleneck.suggestion}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-green-50 rounded-lg border border-green-200 p-6">
          <h3 className="text-lg font-semibold text-green-900 mb-4 flex items-center">
            <Zap className="w-5 h-5 mr-2" />
            Quick Win Opportunities
          </h3>
          <div className="space-y-3">
            {[
              { title: 'Add exit-intent popup', impact: '+15% conversions', effort: 'Low' },
              { title: 'Implement live chat', impact: '+22% engagement', effort: 'Medium' },
              { title: 'A/B test CTA buttons', impact: '+8% click-through', effort: 'Low' },
            ].map((opportunity, i) => (
              <div key={i} className="bg-white rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-medium text-gray-900">{opportunity.title}</p>
                    <p className="text-sm text-green-600">{opportunity.impact}</p>
                  </div>
                  <span className={`px-2 py-1 text-xs font-medium rounded ${
                    opportunity.effort === 'Low' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {opportunity.effort} Effort
                  </span>
                </div>
                <button className="mt-2 px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700 transition-colors">
                  Implement
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================
// 4. REVENUE ATTRIBUTION VIEW
// ============================================

function RevenueAttributionView() {
  return (
    <div className="space-y-6">
      {/* Attribution Model Selector */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Revenue Attribution</h2>
          <p className="text-gray-600">Multi-touch attribution across all channels</p>
        </div>
        <select className="px-4 py-2 border border-gray-300 rounded-lg">
          <option>Time Decay Model</option>
          <option>First Touch</option>
          <option>Last Touch</option>
          <option>Linear</option>
          <option>U-Shaped</option>
          <option>W-Shaped</option>
        </select>
      </div>

      {/* Channel Attribution */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Channel Performance</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 text-gray-600 font-medium">Channel</th>
                <th className="text-right py-3 px-4 text-gray-600 font-medium">Attributed Revenue</th>
                <th className="text-right py-3 px-4 text-gray-600 font-medium">Conversions</th>
                <th className="text-right py-3 px-4 text-gray-600 font-medium">Cost</th>
                <th className="text-right py-3 px-4 text-gray-600 font-medium">ROI</th>
                <th className="text-right py-3 px-4 text-gray-600 font-medium">Trend</th>
              </tr>
            </thead>
            <tbody>
              {[
                { channel: 'Organic Search', revenue: 248750, conversions: 456, cost: 12500, roi: 19.9, trend: 12.5 },
                { channel: 'Paid Search', revenue: 187250, conversions: 342, cost: 45200, roi: 4.1, trend: -3.2 },
                { channel: 'Email', revenue: 156820, conversions: 289, cost: 8900, roi: 17.6, trend: 8.7 },
                { channel: 'Social Media', revenue: 124590, conversions: 234, cost: 28400, roi: 4.4, trend: 15.3 },
                { channel: 'Direct', revenue: 98450, conversions: 178, cost: 0, roi: Infinity, trend: 5.1 },
              ].map((row, i) => (
                <tr key={i} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium text-gray-900">{row.channel}</td>
                  <td className="text-right py-3 px-4 text-gray-900 font-semibold">
                    ${row.revenue.toLocaleString()}
                  </td>
                  <td className="text-right py-3 px-4 text-gray-700">{row.conversions}</td>
                  <td className="text-right py-3 px-4 text-gray-700">${row.cost.toLocaleString()}</td>
                  <td className="text-right py-3 px-4">
                    <span className={`font-semibold ${
                      row.roi > 10 ? 'text-green-600' : row.roi > 5 ? 'text-yellow-600' : 'text-red-600'
                    }`}>
                      {row.roi === Infinity ? '∞' : `${row.roi}x`}
                    </span>
                  </td>
                  <td className="text-right py-3 px-4">
                    <span className={`flex items-center justify-end ${
                      row.trend > 0 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {row.trend > 0 ? <ArrowUp className="w-4 h-4 mr-1" /> : <ArrowDown className="w-4 h-4 mr-1" />}
                      {Math.abs(row.trend)}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Attribution Visualization */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Revenue Distribution</h3>
          <div className="h-72 flex items-center justify-center text-gray-400 border-2 border-dashed rounded-lg">
            [Pie Chart showing revenue % by channel]
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Customer Journey Flow</h3>
          <div className="h-72 flex items-center justify-center text-gray-400 border-2 border-dashed rounded-lg">
            [Sankey diagram showing touch point paths]
          </div>
        </div>
      </div>

      {/* Detailed Journey Example */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Sample Customer Journey</h3>
        <div className="relative">
          <div className="flex items-center justify-between">
            {[
              { channel: 'Google Search', date: 'Jan 15', value: '$120' },
              { channel: 'Email Campaign', date: 'Jan 18', value: '$180' },
              { channel: 'Social Media', date: 'Jan 22', value: '$150' },
              { channel: 'Direct Visit', date: 'Jan 25', value: '$240' },
              { channel: 'Conversion', date: 'Jan 28', value: '$1,500' },
            ].map((touch, i) => (
              <div key={i} className="relative flex-1">
                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-2">
                    <Activity className="w-8 h-8 text-blue-600" />
                  </div>
                  <p className="text-sm font-medium text-gray-900 text-center">{touch.channel}</p>
                  <p className="text-xs text-gray-500">{touch.date}</p>
                  <p className="text-sm font-semibold text-blue-600 mt-1">{touch.value}</p>
                </div>
                {i < 4 && (
                  <div className="absolute top-8 left-1/2 w-full h-0.5 bg-blue-300" />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================
// UTILITY COMPONENTS
// ============================================

function PredictiveMetricCard({
  title,
  value,
  change,
  trend,
  icon: Icon,
  description,
}: any) {
  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-2">
        <p className="text-sm text-gray-600">{title}</p>
        <Icon className="w-5 h-5 text-gray-400" />
      </div>
      <p className="text-3xl font-bold text-gray-900 mb-1">{value}</p>
      <div className="flex items-center space-x-2">
        <span className={`text-sm font-medium ${
          trend === 'up' ? 'text-green-600' : 'text-red-600'
        }`}>
          {change}
        </span>
        <span className="text-sm text-gray-500">{description}</span>
      </div>
    </div>
  );
}
