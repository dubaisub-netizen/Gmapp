// Core Lead Types
export interface Lead {
  id: string;
  place_id: string;
  
  // Basic Info
  name: string;
  address: string;
  street?: string;
  city?: string;
  state?: string;
  zip?: string;
  country?: string;
  
  // Contact
  phone?: string;
  formatted_phone?: string;
  international_phone?: string;
  website?: string;
  email?: string;
  
  // Location
  latitude: number;
  longitude: number;
  plus_code?: string;
  timezone?: string;
  neighborhood?: string;
  
  // Business Details
  category: string;
  types: string[];
  business_status: 'OPERATIONAL' | 'CLOSED_TEMPORARILY' | 'CLOSED_PERMANENTLY';
  price_level?: number;
  
  // Engagement
  rating?: number;
  user_ratings_total?: number;
  reviews?: Review[];
  
  // Hours
  opening_hours?: OpeningHours;
  
  // Social Media
  social_media?: SocialMedia;
  
  // Photos
  photos?: string[];
  logo?: string;
  cover_photo?: string;
  
  // Enrichment
  email_verified?: boolean;
  phone_verified?: boolean;
  website_status?: string;
  
  // AI Analysis
  ai_sentiment?: SentimentAnalysis;
  ai_insights?: string;
  lead_score?: number;
  
  // CRM Fields
  status: LeadStatus;
  assigned_to?: string;
  tags: string[];
  notes: Note[];
  last_contacted?: Date;
  next_follow_up?: Date;
  
  // Metadata
  created_at: Date;
  updated_at: Date;
  scraped_at: Date;
  source: string;
}

export interface Review {
  id: string;
  author_name: string;
  rating: number;
  text: string;
  time: Date;
  profile_photo_url?: string;
  relative_time_description: string;
}

export interface OpeningHours {
  open_now: boolean;
  periods: Period[];
  weekday_text: string[];
}

export interface Period {
  open: { day: number; time: string };
  close?: { day: number; time: string };
}

export interface SocialMedia {
  facebook?: string;
  instagram?: string;
  linkedin?: string;
  twitter?: string;
  youtube?: string;
  tiktok?: string;
}

export interface SentimentAnalysis {
  overall_sentiment: 'positive' | 'neutral' | 'negative';
  positive_percentage: number;
  neutral_percentage: number;
  negative_percentage: number;
  common_themes: string[];
  pros: string[];
  cons: string[];
  summary: string;
}

export interface Note {
  id: string;
  text: string;
  created_by: string;
  created_at: Date;
}

export type LeadStatus = 
  | 'new'
  | 'contacted'
  | 'qualified'
  | 'proposal'
  | 'negotiation'
  | 'won'
  | 'lost';

// Search & Scraping Types
export interface SearchQuery {
  keyword: string;
  location: string;
  radius?: number;
  min_rating?: number;
  max_rating?: number;
  price_level?: number[];
  open_now?: boolean;
  min_reviews?: number;
  max_results?: number;
}

export interface ScrapingJob {
  id: string;
  query: SearchQuery;
  status: 'pending' | 'running' | 'completed' | 'failed';
  progress: number;
  results_count: number;
  started_at?: Date;
  completed_at?: Date;
  error?: string;
  created_by: string;
}

// Analytics Types
export interface DashboardStats {
  total_leads: number;
  leads_today: number;
  leads_this_week: number;
  leads_this_month: number;
  average_rating: number;
  total_reviews: number;
  ai_insights_generated: number;
}

export interface LeadsByCategory {
  category: string;
  count: number;
  percentage: number;
}

export interface LeadsByLocation {
  city: string;
  count: number;
  avg_rating: number;
}

export interface RatingDistribution {
  rating: string;
  count: number;
}

// Export Types
export interface ExportConfig {
  format: 'csv' | 'xlsx' | 'json' | 'pdf';
  fields: string[];
  filters?: FilterConfig;
  include_headers?: boolean;
  filename?: string;
}

export interface FilterConfig {
  status?: LeadStatus[];
  rating_min?: number;
  rating_max?: number;
  categories?: string[];
  tags?: string[];
  date_from?: Date;
  date_to?: Date;
  search?: string;
}

// Report Types
export interface Report {
  id: string;
  name: string;
  type: ReportType;
  config: ReportConfig;
  generated_at: Date;
  file_url?: string;
}

export type ReportType = 
  | 'market_analysis'
  | 'competitive_landscape'
  | 'lead_performance'
  | 'campaign_performance'
  | 'executive_summary';

export interface ReportConfig {
  date_range: { from: Date; to: Date };
  metrics: string[];
  charts: string[];
  filters?: FilterConfig;
}

// User & Team Types
export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  avatar?: string;
  created_at: Date;
}

export type UserRole = 'admin' | 'manager' | 'sales_rep' | 'analyst' | 'viewer';

// Automation Types
export interface Workflow {
  id: string;
  name: string;
  trigger: WorkflowTrigger;
  actions: WorkflowAction[];
  conditions?: WorkflowCondition[];
  active: boolean;
  created_at: Date;
}

export interface WorkflowTrigger {
  type: 'new_lead' | 'status_change' | 'schedule' | 'manual';
  config: any;
}

export interface WorkflowAction {
  type: 'assign' | 'tag' | 'email' | 'webhook' | 'export' | 'enrich';
  config: any;
}

export interface WorkflowCondition {
  field: string;
  operator: 'equals' | 'contains' | 'greater_than' | 'less_than';
  value: any;
}

// AI Types
export interface AIAnalysisRequest {
  lead_id: string;
  analysis_type: 'sentiment' | 'competitive' | 'scoring' | 'outreach';
  options?: any;
}

export interface AIAnalysisResult {
  lead_id: string;
  analysis_type: string;
  result: any;
  confidence: number;
  generated_at: Date;
}

export interface CompetitorAnalysis {
  competitors: Lead[];
  market_position: {
    rating_rank: number;
    review_count_rank: number;
    total_competitors: number;
  };
  swot: {
    strengths: string[];
    weaknesses: string[];
    opportunities: string[];
    threats: string[];
  };
  recommendations: string[];
}

// Integration Types
export interface Integration {
  id: string;
  name: string;
  type: 'crm' | 'email' | 'automation' | 'storage';
  provider: string;
  config: any;
  active: boolean;
  connected_at: Date;
}

// Monitoring Types
export interface Alert {
  id: string;
  type: 'competitor_change' | 'new_business' | 'rating_drop' | 'custom';
  title: string;
  message: string;
  severity: 'info' | 'warning' | 'critical';
  lead_id?: string;
  created_at: Date;
  read: boolean;
}

// Map Types
export interface MapMarker {
  id: string;
  position: [number, number]; // [lng, lat]
  lead: Lead;
  color?: string;
}

export interface MapBounds {
  north: number;
  south: number;
  east: number;
  west: number;
}
