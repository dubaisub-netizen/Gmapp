// Phase 11: AI Agents & Automation Types

// ============================================
// VOICE AI FOR COLD CALLING
// ============================================

export interface VoiceAIAgent {
  id: string;
  name: string;
  voice_id: string; // Voice model (male/female, accent, tone)
  personality: 'professional' | 'friendly' | 'energetic' | 'calm';
  language: string;
  script_template: CallScript;
  status: 'active' | 'paused' | 'training';
  calls_made: number;
  success_rate: number;
  created_at: Date;
}

export interface CallScript {
  id: string;
  name: string;
  opening: string;
  objection_handling: ObjectionResponse[];
  qualifying_questions: string[];
  closing: string;
  fallback_responses: string[];
}

export interface ObjectionResponse {
  objection: string;
  response: string;
  follow_up: string[];
}

export interface VoiceCall {
  id: string;
  agent_id: string;
  lead_id: string;
  phone_number: string;
  status: 'scheduled' | 'in_progress' | 'completed' | 'failed' | 'voicemail';
  started_at?: Date;
  ended_at?: Date;
  duration_seconds?: number;
  transcript: CallTranscript[];
  sentiment: 'positive' | 'neutral' | 'negative';
  outcome: CallOutcome;
  recording_url?: string;
  cost: number;
}

export interface CallTranscript {
  speaker: 'ai' | 'human';
  text: string;
  timestamp: number;
  confidence: number;
  sentiment?: string;
}

export interface CallOutcome {
  result: 'interested' | 'not_interested' | 'callback' | 'voicemail' | 'no_answer';
  appointment_scheduled?: boolean;
  appointment_date?: Date;
  next_action?: string;
  notes?: string;
}

// ============================================
// AI CHATBOT FOR LEAD QUALIFICATION
// ============================================

export interface ChatbotAgent {
  id: string;
  name: string;
  type: 'website' | 'whatsapp' | 'facebook' | 'sms' | 'email';
  personality: string;
  qualification_criteria: QualificationCriteria;
  conversation_flow: ConversationNode[];
  active: boolean;
  conversations: number;
  qualified_leads: number;
  created_at: Date;
}

export interface QualificationCriteria {
  budget_range?: { min: number; max: number };
  timeline?: string;
  decision_maker?: boolean;
  company_size?: string;
  industry?: string[];
  custom_fields?: { field: string; required: boolean; type: string }[];
}

export interface ConversationNode {
  id: string;
  type: 'question' | 'statement' | 'branch' | 'action';
  content: string;
  options?: string[];
  next_node?: string | ConversationBranch[];
  qualification_score?: number;
  action?: 'qualify' | 'disqualify' | 'schedule' | 'transfer' | 'collect_info';
}

export interface ConversationBranch {
  condition: string;
  next_node: string;
}

export interface ChatConversation {
  id: string;
  chatbot_id: string;
  lead_id?: string;
  channel: 'website' | 'whatsapp' | 'facebook' | 'sms' | 'email';
  messages: ChatMessage[];
  qualified: boolean;
  qualification_score: number;
  collected_data: Record<string, any>;
  started_at: Date;
  ended_at?: Date;
  status: 'active' | 'completed' | 'abandoned';
}

export interface ChatMessage {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  timestamp: Date;
  intent?: string;
  entities?: Record<string, any>;
  confidence?: number;
}

// ============================================
// PREDICTIVE LEAD SCORING 2.0
// ============================================

export interface AdvancedLeadScore {
  lead_id: string;
  overall_score: number; // 0-100
  dimension_scores: {
    fit: number; // How well they match ICP
    intent: number; // Buying signals
    engagement: number; // Activity level
    urgency: number; // Time sensitivity
  };
  signals: LeadSignal[];
  recommended_actions: string[];
  priority: 'critical' | 'high' | 'medium' | 'low';
  decay_rate: number; // Score decreases over time if no action
  next_best_action: string;
  predicted_deal_size: number;
  predicted_close_date: Date;
}

export interface LeadSignal {
  type: 'positive' | 'negative' | 'neutral';
  signal: string;
  impact: number; // -10 to +10
  timestamp: Date;
  source: string;
}

// ============================================
// AUTO-NEGOTIATION BOT
// ============================================

export interface NegotiationBot {
  id: string;
  name: string;
  strategy: NegotiationStrategy;
  pricing_rules: PricingRule[];
  approval_required_threshold: number; // Above this discount, needs human approval
  active: boolean;
  negotiations_handled: number;
  success_rate: number;
}

export interface NegotiationStrategy {
  starting_position: 'high' | 'medium' | 'fair';
  concession_pattern: 'linear' | 'diminishing' | 'hardball';
  max_discount_percentage: number;
  min_acceptable_margin: number;
  tactics: NegotiationTactic[];
}

export interface NegotiationTactic {
  name: string;
  description: string;
  when_to_use: string;
  effectiveness: number;
}

export interface PricingRule {
  id: string;
  condition: string;
  action: 'discount' | 'bundle' | 'upgrade' | 'extend_trial' | 'add_value';
  value: number | string;
  priority: number;
}

export interface NegotiationSession {
  id: string;
  bot_id: string;
  lead_id: string;
  deal_value: number;
  requested_discount: number;
  offered_discount: number;
  final_discount?: number;
  status: 'in_progress' | 'agreed' | 'rejected' | 'escalated';
  messages: NegotiationMessage[];
  started_at: Date;
  ended_at?: Date;
}

export interface NegotiationMessage {
  sender: 'bot' | 'lead';
  message: string;
  offer?: number;
  timestamp: Date;
}

// ============================================
// SMART APPOINTMENT SCHEDULER
// ============================================

export interface SmartScheduler {
  id: string;
  name: string;
  calendar_integration: 'google' | 'outlook' | 'calendly';
  availability_rules: AvailabilityRule[];
  buffer_time: number; // minutes between meetings
  meeting_types: MeetingType[];
  auto_reschedule: boolean;
  reminder_settings: ReminderSettings;
}

export interface AvailabilityRule {
  day_of_week: number; // 0-6
  start_time: string;
  end_time: string;
  timezone: string;
}

export interface MeetingType {
  id: string;
  name: string;
  duration: number; // minutes
  description: string;
  booking_url?: string;
}

export interface ReminderSettings {
  enabled: boolean;
  intervals: number[]; // [24, 1] = 24 hours and 1 hour before
  channels: ('email' | 'sms' | 'push')[];
}

// ============================================
// AI EMAIL ASSISTANT
// ============================================

export interface EmailAssistant {
  id: string;
  name: string;
  email_account: string;
  auto_reply: boolean;
  auto_follow_up: boolean;
  follow_up_sequence: EmailSequence[];
  tone: 'professional' | 'casual' | 'friendly' | 'formal';
  active: boolean;
}

export interface EmailSequence {
  id: string;
  step: number;
  delay_days: number;
  subject_template: string;
  body_template: string;
  conditions?: string[];
  stop_if?: string;
}

export interface EmailAnalysis {
  email_id: string;
  lead_id: string;
  intent: 'interested' | 'not_interested' | 'question' | 'objection' | 'pricing';
  sentiment: 'positive' | 'neutral' | 'negative';
  urgency: 'high' | 'medium' | 'low';
  entities: Record<string, any>;
  suggested_response: string;
  confidence: number;
}

// ============================================
// WORKFLOW AUTOMATION 2.0
// ============================================

export interface AdvancedWorkflow {
  id: string;
  name: string;
  description: string;
  trigger: WorkflowTrigger;
  conditions: WorkflowCondition[];
  actions: WorkflowAction[];
  ai_optimization: boolean; // AI learns and optimizes workflow
  status: 'active' | 'paused' | 'draft';
  runs: number;
  success_rate: number;
  created_at: Date;
}

export interface WorkflowTrigger {
  type: 'event' | 'schedule' | 'webhook' | 'ai_signal';
  config: Record<string, any>;
}

export interface WorkflowCondition {
  type: 'if' | 'and' | 'or' | 'not';
  field: string;
  operator: string;
  value: any;
}

export interface WorkflowAction {
  type: string;
  config: Record<string, any>;
  ai_generated?: boolean; // Action suggested by AI
  success_rate?: number;
}

// ============================================
// CONVERSATIONAL AI ANALYTICS
// ============================================

export interface ConversationAnalytics {
  period: string;
  total_conversations: number;
  qualified_leads: number;
  qualification_rate: number;
  avg_conversation_length: number;
  top_intents: IntentAnalysis[];
  sentiment_distribution: {
    positive: number;
    neutral: number;
    negative: number;
  };
  drop_off_points: DropOffAnalysis[];
  success_patterns: string[];
}

export interface IntentAnalysis {
  intent: string;
  count: number;
  conversion_rate: number;
  avg_score: number;
}

export interface DropOffAnalysis {
  step: string;
  drop_off_rate: number;
  reason: string;
  suggestion: string;
}

// ============================================
// AI AGENT PERFORMANCE
// ============================================

export interface AgentPerformance {
  agent_id: string;
  agent_type: 'voice' | 'chat' | 'email' | 'negotiation';
  metrics: {
    interactions: number;
    success_rate: number;
    avg_handling_time: number;
    cost_per_interaction: number;
    roi: number;
  };
  quality_scores: {
    accuracy: number;
    relevance: number;
    politeness: number;
    effectiveness: number;
  };
  improvement_suggestions: string[];
  a_b_test_results?: ABTestResult[];
}

export interface ABTestResult {
  test_name: string;
  variant_a: string;
  variant_b: string;
  winner: 'a' | 'b' | 'no_difference';
  confidence: number;
  metric: string;
}

// ============================================
// INTEGRATION WITH EXISTING PHASES
// ============================================

export interface Phase11Integration {
  // Voice AI calls leads from predictive analytics
  voice_ai_integration: {
    auto_call_high_probability_leads: boolean;
    call_schedule_optimization: boolean;
  };
  
  // Chatbot qualifies leads before assigning
  chatbot_integration: {
    auto_qualify_before_assignment: boolean;
    route_to_appropriate_team: boolean;
  };
  
  // Negotiation bot uses attribution data
  negotiation_integration: {
    consider_customer_value: boolean;
    adjust_strategy_by_channel: boolean;
  };
  
  // All agents learn from cohort analysis
  learning_integration: {
    optimize_based_on_retention: boolean;
    adapt_to_successful_patterns: boolean;
  };
}
