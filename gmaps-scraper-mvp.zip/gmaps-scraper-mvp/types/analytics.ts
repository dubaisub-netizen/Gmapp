// Advanced Analytics Types

// ============================================
// PREDICTIVE ANALYTICS
// ============================================

export interface PredictiveModel {
  id: string;
  name: string;
  type: 'linear_regression' | 'polynomial' | 'exponential' | 'neural_network';
  target: string; // What we're predicting
  features: string[]; // Input features
  accuracy: number; // Model accuracy (0-1)
  trained_at: Date;
  predictions: number;
}

export interface LeadConversionPrediction {
  lead_id: string;
  conversion_probability: number; // 0-1
  predicted_revenue: number;
  predicted_close_date: Date;
  confidence_interval: {
    lower: number;
    upper: number;
  };
  factors: PredictionFactor[];
}

export interface PredictionFactor {
  feature: string;
  importance: number; // 0-1
  value: any;
  impact: 'positive' | 'negative' | 'neutral';
}

export interface ChurnPrediction {
  lead_id: string;
  churn_probability: number; // 0-1
  risk_level: 'low' | 'medium' | 'high' | 'critical';
  churn_date_estimate: Date;
  retention_actions: string[];
  factors: PredictionFactor[];
}

export interface RevenueForecast {
  period: string; // 'Q1 2024', 'Feb 2024', etc.
  predicted_revenue: number;
  confidence_interval: {
    lower: number;
    upper: number;
  };
  breakdown: {
    new_business: number;
    expansion: number;
    renewal: number;
  };
  historical_data: HistoricalRevenue[];
}

export interface HistoricalRevenue {
  period: string;
  actual_revenue: number;
  predicted_revenue?: number;
  variance?: number;
}

// ============================================
// COHORT ANALYSIS
// ============================================

export interface Cohort {
  id: string;
  name: string;
  definition: CohortDefinition;
  size: number;
  created_at: Date;
  first_seen: Date;
}

export interface CohortDefinition {
  type: 'acquisition' | 'behavioral' | 'demographic' | 'custom';
  criteria: {
    field: string;
    operator: string;
    value: any;
  }[];
  time_period: {
    start: Date;
    end: Date;
  };
}

export interface CohortAnalysis {
  cohort_id: string;
  metric: string; // 'retention', 'revenue', 'engagement', etc.
  data: CohortPeriodData[];
  retention_curve: RetentionCurve;
  lifetime_value: number;
  insights: string[];
}

export interface CohortPeriodData {
  period: number; // 0 (acquisition), 1 (month 1), 2 (month 2), etc.
  date: Date;
  size: number;
  active: number;
  retention_rate: number; // %
  revenue: number;
  cumulative_revenue: number;
  average_value: number;
}

export interface RetentionCurve {
  periods: number[];
  retention_rates: number[];
  trend: 'improving' | 'stable' | 'declining';
  half_life: number; // Period when 50% retention reached
}

export interface CohortComparison {
  cohorts: Cohort[];
  metric: string;
  winner: string; // cohort_id with best performance
  comparison_data: {
    cohort_id: string;
    avg_value: number;
    trend: number;
    performance_vs_baseline: number; // %
  }[];
}

// ============================================
// FUNNEL OPTIMIZATION
// ============================================

export interface ConversionFunnel {
  id: string;
  name: string;
  stages: FunnelStage[];
  total_entries: number;
  total_conversions: number;
  overall_conversion_rate: number;
  average_time_to_convert: number; // days
  created_at: Date;
}

export interface FunnelStage {
  id: string;
  name: string;
  order: number;
  entries: number;
  exits: number;
  conversions: number; // to next stage
  conversion_rate: number; // %
  drop_off_rate: number; // %
  average_time_in_stage: number; // days
  bottleneck_score: number; // 0-100, higher = bigger bottleneck
}

export interface FunnelAnalysis {
  funnel_id: string;
  time_period: {
    start: Date;
    end: Date;
  };
  performance: {
    total_conversions: number;
    conversion_rate: number;
    trend: number; // % change vs previous period
  };
  bottlenecks: FunnelBottleneck[];
  opportunities: FunnelOpportunity[];
  segment_analysis: SegmentFunnelPerformance[];
}

export interface FunnelBottleneck {
  stage_id: string;
  stage_name: string;
  drop_off_rate: number;
  impact_on_revenue: number;
  suggested_actions: string[];
  priority: 'critical' | 'high' | 'medium' | 'low';
}

export interface FunnelOpportunity {
  type: 'quick_win' | 'high_impact' | 'long_term';
  description: string;
  potential_improvement: number; // % or $
  effort_required: 'low' | 'medium' | 'high';
  priority_score: number; // 0-100
}

export interface SegmentFunnelPerformance {
  segment: string;
  conversion_rate: number;
  average_time: number;
  performance_vs_average: number; // %
  insights: string[];
}

export interface FunnelExperiment {
  id: string;
  name: string;
  stage_id: string;
  hypothesis: string;
  variant_a: FunnelVariant;
  variant_b: FunnelVariant;
  status: 'draft' | 'running' | 'completed' | 'paused';
  started_at?: Date;
  completed_at?: Date;
  winner?: 'a' | 'b' | 'no_difference';
  confidence: number; // statistical significance %
}

export interface FunnelVariant {
  name: string;
  description: string;
  traffic_allocation: number; // %
  conversions: number;
  conversion_rate: number;
  improvement: number; // % vs control
}

// ============================================
// REVENUE ATTRIBUTION
// ============================================

export interface AttributionModel {
  id: string;
  name: string;
  type: AttributionModelType;
  description: string;
  settings: any;
}

export type AttributionModelType =
  | 'first_touch'
  | 'last_touch'
  | 'linear'
  | 'time_decay'
  | 'u_shaped'
  | 'w_shaped'
  | 'custom';

export interface TouchPoint {
  id: string;
  lead_id: string;
  channel: string; // 'google_search', 'email', 'social', etc.
  campaign?: string;
  source?: string;
  medium?: string;
  content?: string;
  timestamp: Date;
  event_type: 'view' | 'click' | 'engagement' | 'conversion';
  value?: number;
  session_id: string;
}

export interface CustomerJourney {
  lead_id: string;
  touch_points: TouchPoint[];
  total_touchpoints: number;
  first_touch: TouchPoint;
  last_touch: TouchPoint;
  converting_touch: TouchPoint;
  journey_duration: number; // days
  total_value: number;
}

export interface AttributionReport {
  model: AttributionModel;
  time_period: {
    start: Date;
    end: Date;
  };
  total_revenue: number;
  channel_attribution: ChannelAttribution[];
  campaign_attribution: CampaignAttribution[];
  roi_analysis: ROIAnalysis[];
  insights: AttributionInsight[];
}

export interface ChannelAttribution {
  channel: string;
  attributed_revenue: number;
  attributed_conversions: number;
  percentage_of_total: number;
  cost: number;
  roi: number;
  trend: number; // % change
  touch_points: number;
  average_position_in_journey: number;
}

export interface CampaignAttribution {
  campaign: string;
  channel: string;
  attributed_revenue: number;
  attributed_conversions: number;
  cost: number;
  roi: number;
  cac: number; // Customer Acquisition Cost
  ltv: number; // Lifetime Value
  ltv_cac_ratio: number;
  efficiency_score: number; // 0-100
}

export interface ROIAnalysis {
  entity: string; // channel, campaign, source
  type: 'channel' | 'campaign' | 'source';
  invested: number;
  returned: number;
  roi: number;
  roi_percentage: number;
  payback_period: number; // days
  performance: 'excellent' | 'good' | 'average' | 'poor';
}

export interface AttributionInsight {
  type: 'opportunity' | 'warning' | 'trend' | 'recommendation';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  action_items: string[];
  potential_value?: number;
}

// ============================================
// MULTI-TOUCH ATTRIBUTION
// ============================================

export interface MultiTouchAttribution {
  lead_id: string;
  total_value: number;
  attribution_breakdown: TouchPointAttribution[];
  journey_visualization: JourneyNode[];
  conversion_path: string;
}

export interface TouchPointAttribution {
  touchpoint_id: string;
  channel: string;
  timestamp: Date;
  attributed_value: number;
  attribution_percentage: number;
  weight: number;
  position_in_journey: number;
}

export interface JourneyNode {
  id: string;
  type: 'touchpoint' | 'conversion' | 'milestone';
  channel: string;
  timestamp: Date;
  value: number;
  next_nodes: string[];
}

// ============================================
// ADVANCED METRICS
// ============================================

export interface AdvancedMetrics {
  // Predictive
  predicted_monthly_revenue: number;
  predicted_churn_rate: number;
  predicted_ltv: number;
  
  // Cohort
  cohort_retention_30d: number;
  cohort_retention_90d: number;
  cohort_ltv: number;
  
  // Funnel
  funnel_conversion_rate: number;
  funnel_velocity: number; // avg days to convert
  funnel_bottleneck_stage: string;
  
  // Attribution
  best_performing_channel: string;
  average_touchpoints_to_conversion: number;
  multi_touch_attribution_roi: number;
  
  // Combined
  customer_health_score: number; // 0-100
  growth_rate: number;
  efficiency_score: number;
}

export interface MetricTrend {
  metric: string;
  current_value: number;
  previous_value: number;
  change: number;
  change_percentage: number;
  trend: 'up' | 'down' | 'stable';
  forecast_next_period: number;
}

// ============================================
// ANALYTICS DASHBOARD CONFIG
// ============================================

export interface AnalyticsDashboard {
  id: string;
  name: string;
  widgets: AnalyticsWidget[];
  layout: DashboardLayout;
  filters: DashboardFilter[];
  refresh_interval: number; // seconds
  shared: boolean;
  created_by: string;
  created_at: Date;
}

export interface AnalyticsWidget {
  id: string;
  type: 'predictive' | 'cohort' | 'funnel' | 'attribution' | 'metric' | 'chart';
  title: string;
  data_source: string;
  config: any;
  position: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

export interface DashboardLayout {
  columns: number;
  rows: number;
  responsive: boolean;
}

export interface DashboardFilter {
  field: string;
  operator: string;
  value: any;
  active: boolean;
}
